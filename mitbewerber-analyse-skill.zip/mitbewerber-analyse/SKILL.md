---
name: mitbewerber-analyse
description: Führt eine strukturierte Mitbewerber-Analyse für dein Business durch — recherchiert deine Mitbewerber im Web und wertet Online-Auftritt, Angebot, Preise, Content, Werbeanzeigen und Ähnlichkeit zu deinem eigenen Business aus. Nutze diesen Skill, wenn du "Mitbewerber-Analyse", "Konkurrenzanalyse", "Wettbewerber checken" sagst oder wissen willst, wie sich andere Coaches/Anbieter in deiner Nische positionieren, welche Preise sie nehmen, oder was ihre Werbung und ihr Content machen.
---

# Mitbewerber-Analyse mit Claude

Diese Skill führt eine vollständige Mitbewerber-Analyse durch — direkt mit Web-Recherche statt einer von Hand ausgefüllten Tabelle. Am Ende bekommt die Person eine übersichtliche, strukturierte Auswertung ihrer Mitbewerber plus eine ehrliche Einschätzung, was das für ihre eigene Positionierung bedeutet.

## Ablauf

### Schritt 1: Grundlagen klären

Bevor du recherchierst, brauchst du:

1. **In welcher Nische/Branche** ist die Person unterwegs? (z.B. "Business-Coaching für Mütter", "Ernährungsberatung", "Yoga-Lehrerin")
2. **Kennt sie schon konkrete Mitbewerber** (Namen), oder soll Claude passende Mitbewerber selbst finden?
3. **Wie viele Mitbewerber** sollen analysiert werden? (Vorschlag: 5-10 — bei mehr als 10 wird es unübersichtlich und die Recherche dauert entsprechend länger)

Wenn eine dieser Angaben fehlt, frag kurz nach — aber nur einmal, nicht mehrfach hintereinander. Wenn die Person direkt Namen nennt, geh sofort in die Recherche.

### Schritt 2: Mitbewerber finden (falls nötig)

Wenn keine konkreten Namen genannt wurden: recherchiere per Web-Suche nach den relevantesten Anbietern in der genannten Nische. Suche gezielt nach Begriffen wie "[Nische] Coach", "[Nische] Kurs", "beste [Nische] Anbieter" und identifiziere 5-10 Anbieter, die entweder eine vorbildliche Positionierung haben oder eine sehr ähnliche Zielgruppe ansprechen.

### Schritt 3: Pro Mitbewerber recherchieren

Für jeden Mitbewerber, recherchiere und fasse zusammen (in eigenen Worten, siehe Copyright-Hinweis unten):

**Online-Auftritt**
- Website-URL, Social-Media-Profile (Instagram, Facebook, LinkedIn)
- Wie wirkt die Website? Wording, Ansprache, Design-Eindruck

**Angebot**
- Welche Produkte/Dienstleistungen werden angeboten?
- Die 3 wichtigsten USPs (Alleinstellungsmerkmale) — was macht das Angebot einzigartig?
- Wie verändert sich das Leben der Kunden nach dem Kauf? (aus Testimonials/Bewertungen ableiten, falls auffindbar)
- Preise (falls öffentlich einsehbar)
- Garantien und besondere Services (z.B. Geld-zurück-Garantie, Support)
- Freebies (kostenlose Lead-Magnete)
- Erkennbarer Funnel (z.B. Freebie → E-Mail-Sequenz → Angebot)
- Aktuelle Promos/Rabattaktionen

**Content**
- Welche Themen dominieren auf Social Media, Blog, YouTube?
- Auffällige, gut performende Beiträge (falls erkennbar an Engagement)

**Werbeanzeigen**
- Falls auffindbar (z.B. über Hinweise auf der Website oder in Suchergebnissen): welche Art von Anzeigen/Werbebotschaften nutzt der Mitbewerber?
- Hinweis: Nutze KEINE Login-geschützten Werbebibliotheken (z.B. Facebook Ads Library erfordert Login) — arbeite nur mit frei zugänglichen Informationen.

**Ähnlichkeit zur Person selbst**
- Bewerte auf einer Skala 1-5 (1 = kaum ähnlich, 5 = sehr ähnlich/direkter Wettbewerb), wie ähnlich Angebot und Zielgruppe zur Person sind
- Kurze Begründung der Einschätzung

### Schritt 4: Ergebnis strukturieren

Präsentiere die Ergebnisse als **übersichtliche Tabelle** (eine Zeile pro Mitbewerber, die Spalten oben als Kategorien), am besten als Artefakt/Datei, damit die Person es speichern und weiterverwenden kann. Spaltenstruktur (angelehnt an die bewährte MUMTY-Vorlage):

`Mitbewerber Name | Website/Social Media | Produkte | 3 USPs | Preise | Garantien & Services | Freebies | Funnel | Content-Themen | Ähnlichkeit (1-5)`

### Schritt 5: Einordnung geben (das Wichtigste!)

Eine reine Datentabelle ist nur die halbe Arbeit. Danach IMMER eine kurze, ehrliche Einordnung liefern:

- **Muster über alle Mitbewerber hinweg:** Was machen (fast) alle gleich? (z.B. alle nutzen dieselbe Preisspanne, denselben Funnel-Aufbau)
- **Lücke/Chance:** Was macht noch niemand oder kaum jemand? Wo könnte sich die Person differenzieren?
- **Nicht kopieren, sondern lernen:** Betone, dass es nicht darum geht, das Beste einfach zu übernehmen, sondern zu verstehen, was funktioniert — und dann die eigene, unverwechselbare Version davon zu bauen.

## Wichtige Leitplanken

- **Kein Copy-Paste fremder Texte.** Werbetexte, Website-Formulierungen oder Post-Inhalte der Mitbewerber immer in eigenen Worten zusammenfassen, nie wortwörtlich übernehmen (Copyright). Kurze, klar gekennzeichnete Zitate (unter 15 Wörtern) sind in Ordnung, wenn sie wirklich nötig sind.
- **Keine Falschbehauptungen.** Wenn eine Information (z.B. genaue Preise oder Umsatzzahlen) nicht öffentlich auffindbar ist, ehrlich "nicht öffentlich einsehbar" schreiben statt zu raten.
- **Fair bleiben.** Die Analyse dient der eigenen Positionierung, nicht dem Schlechtreden anderer Anbieter. Ton sachlich und wertschätzend halten, auch wenn Schwachstellen benannt werden.
- **Realistischer Umfang.** Eine gründliche Recherche pro Mitbewerber braucht mehrere Suchanfragen. Bei 8-10 Mitbewerbern kann das eine Weile dauern — kurz ankündigen, dass die vollständige Recherche etwas Zeit braucht, statt oberflächlich draufzuschauen.
