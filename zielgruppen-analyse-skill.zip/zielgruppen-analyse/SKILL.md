---
name: zielgruppen-analyse
description: Baut eine strukturierte Zielgruppen-Tabelle für dein Business auf — führt dich durch ein Interview zu deinen echten oder potenziellen Kunden (demografisch, psychografisch, emotional, Kaufmotive) und/oder recherchiert typische Zielgruppen-Merkmale in deiner Nische, wenn du noch keine Kunden hast. Nutze diesen Skill, wenn du "Zielgruppen-Analyse", "Kundenavatar", "Buyer Persona" oder "wer ist meine Zielgruppe" sagst, oder wissen willst, was deine (potenziellen) Kunden wirklich bewegt, fürchten oder sich wünschen.
---

# Zielgruppen-Analyse mit Claude

Diese Skill baut Schritt für Schritt eine strukturierte Zielgruppen-Tabelle auf — als Interview mit der Person über ihre echten Kunden, ergänzt durch Recherche, wenn noch keine Kunden vorhanden sind. Am Ende gibt es eine ausgefüllte Tabelle (ein oder mehrere Kontakte) plus eine ehrliche Einordnung: welche Muster sich zeigen und was das fürs eigene Business bedeutet.

## Ablauf

### Schritt 1: Ausgangslage klären

Frag kurz (nicht mehr als nötig):

1. **Hat die Person schon Kunden/Interessenten**, über die sie erzählen kann (aus Gesprächen, Interviews, Verkaufsgesprächen)? Oder soll ein erster Zielgruppen-Avatar auf Basis von Recherche und ihrer Vorstellung entstehen?
2. **Für einen oder mehrere Kontakte** gleichzeitig? (Das Original-Tool empfiehlt langfristig 50-200 Kontakte für belastbare Muster — aber ein Start mit 1-3 ist völlig normal und schon wertvoll.)

Wenn die Person direkt loslegt und Infos zu einer Person erzählt, nicht extra nachfragen — sofort ins Interview einsteigen.

### Schritt 2: Interview führen (wenn echte Kunden/Kontakte vorhanden)

Stell die Fragen conversational, nicht wie ein Formular abgehakt — aber decke am Ende alle diese Kategorien ab:

**Demografische Daten**
Alter, Geschlecht, Bildungsstand, Ausbildung/Beruf, Positionierung im Beruf, Einkommen & Budget, Branche, Beziehungsstatus/Familie/Kinder, Sprache, bevorzugter Sprachstil (locker/formell), Hobbys & Interessen

**Geografische Daten**
Wohnort/Stadt, Region, Land

**Werte und Lebensstil**
Mindset, Werte und Überzeugungen, Lebensstil, wonach trifft die Person Kaufentscheidungen

**Emotionen, Bedürfnisse und Kaufmotive** (der wichtigste Teil!)
Herausforderungen und Probleme, Befürchtungen/Ängste/Zweifel, Bedürfnisse/Wünsche/Ziele/Träume, die eigentlichen Kaufmotive (das tiefere WARUM hinter den Zielen — nicht nur die Oberfläche), häufigste Einwände gegen einen Kauf

**Mitbewerber-Bezug**
Welche anderen Coaches/Marken/Produkte zieht diese Person in Betracht oder nutzt sie bereits? Positive/negative Erfahrungen damit?

**Level, Fähigkeiten und Bewusstsein**
Markentreue/Loyalität, Technologieaffinität, Wissens-/Erfahrungslevel in dem Thema, Problembewusstsein (weiß die Person überhaupt, dass sie ein Problem hat?)

**Feedback und Fit**
Falls schon Kunde: Testimonial/Feedback, wie hat sich das Leben nach dem Produkt verändert? Wie gut passt diese Person zum eigenen Angebot (1-5)?

**Wording**
Basierend auf allem Vorherigen: 2-3 Beispielsätze, wie man genau diese Person am besten anspricht

### Schritt 3: Ohne bestehende Kunden — Recherche-Modus

Wenn die Person noch keine Kunden hat: Nutze Web-Suche, um typische Merkmale, Sorgen und Sprache der Zielgruppe in der genannten Nische zu recherchieren (z.B. Foren, Rezensionen zu ähnlichen Angeboten, Social-Media-Diskussionen). Kombiniere das mit den eigenen Vorstellungen der Person von ihrem Wunschkunden. Kennzeichne recherchierte vs. erdachte Annahmen klar als solche — nichts als Fakt ausgeben, was eine Vermutung ist.

### Schritt 4: Ergebnis strukturieren

Präsentiere das Ergebnis als **Tabelle** (idealerweise als Artefakt/Datei), eine Zeile pro Kontakt, mit den Original-Spalten:

`Name | Alter/Geschlecht/Beruf/Einkommen | Wohnort/Region | Werte & Lebensstil | Herausforderungen & Ängste | Bedürfnisse & Ziele | Kaufmotive | Häufigste Einwände | Mitbewerber-Bezug | Problembewusstsein | Perfekter Kunde (1-5) | Beispiel-Wording`

### Schritt 5: Einordnung geben

Nach der Tabelle immer:
- **Muster über mehrere Kontakte:** Was taucht immer wieder auf (gleiche Ängste, gleiche Einwände, gleiche Sprache)?
- **Das eigentliche Kaufmotiv:** Grab tiefer als die Oberfläche — was ist die emotionale Wahrheit hinter dem, was die Person sagt, dass sie will?
- **Konkrete nächste Schritte:** z.B. welches Wording sofort nutzbar ist, wo noch Recherchelücken sind

## Wichtige Leitplanken

- **Keine Erfindungen als Fakten.** Wenn Angaben unklar oder nicht recherchierbar sind, ehrlich "unbekannt/nicht recherchierbar" markieren statt zu raten und als sicher darzustellen.
- **Sensible Angaben mit Bedacht.** Einkommen, Gesundheitszustand, familiäre Situation sind persönliche Daten — auch wenn es die eigenen Kunden der Person sind, keine echten Nachnamen oder eindeutig identifizierende Details in Beispieltabellen verwenden, die evtl. geteilt oder gespeichert werden. Im Zweifel Platzhalter-Vornamen nutzen.
- **Ein Kontakt ist ein Anfang, keine Statistik.** Bei nur 1-3 Kontakten transparent machen, dass die erkannten "Muster" vorläufig sind — erst ab deutlich mehr Kontakten wird daraus verlässliches Wissen.
